import random

while True:
    rolled_num = random.randint(1,6)
    print("The dice rolled and you got: ", rolled_num)
    input("Press any key to roll again.")
